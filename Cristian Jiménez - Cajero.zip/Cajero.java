import java.util.Scanner;
import java.lang.reflect.Array;
import java.util.Random;
import java.math.BigInteger;
public class Cajero{
	public static void main (String args[]){
	Scanner saldo = new Scanner(System.in);
	Random rand = new Random();
	BigInteger numTrans = new BigInteger(50, rand);
	//***** Usuarios *****
	System.out.println("========================================================");
	System.out.println("|*****BIENVENIDO A NUESTRA RED DE CAJEROS A.G.P.V.*****|");
	System.out.println("===================================================================");
	System.out.println("|***** Buen dia estimado cliente este es el men� de usuarios *****|");
	System.out.println("===================================================================");
	System.out.println("|Por favor ingresa tu nombre de usuario|");
	System.out.println("========================================");
	String usuario, contrasenia;
	usuario = saldo.nextLine();
	System.out.println("===================================================");
	System.out.println("|Por favor ingresa tu contrase�a|");
	System.out.println("===================================================");
	contrasenia = saldo.nextLine();
	System.out.println("=================================");


	//___________________________  PRIMER USUARIO ____________________________
	
	if (usuario.equals("Cristian") && contrasenia.equals("1234")){
		System.out.println("|Bienvenido a tu cuenta bancaria|");
		//***** Menu de opciones *****
	int sal = 0;
	while(sal <= 1){
	System.out.println("==============================");
	System.out.println("|***** Menu de opciones *****|");
	System.out.println("==============================");
	System.out.println("1.Consultar saldo");
	int saldo1 = 2000;
	System.out.println("2.Realizar debito");
	System.out.println("3.Realizar debito variable");
	System.out.println("==============================");
	System.out.println("+++++ Escoja una opcion +++++");
	System.out.println("==============================");
	int op;
	op = saldo.nextInt();
	System.out.println("==============================");
	int a,s,d,f,g,h,x, mvariable1, mvaraible2;
	int mvariable;
	int max = 0;
	a = 50;
	s = 100;
	d = 200;
	f = 300;
	g = 500;
	h = 1000;
	
	switch(op){
		
		case 1:
		System.out.println("|Su saldo actual es: " + saldo1 + "|");
		System.out.println("==============================");
		break;
		
		
		case 2:
		System.out.println("+++++ Escoja una opcion +++++");
		x = 0;
		System.out.println("1. 50");
		System.out.println("2. 100");
		System.out.println("3. 200");
		System.out.println("4. 300");
		System.out.println("5. 500");
		System.out.println("6. 1000");
		System.out.println("===========================================================");
		System.out.println("|Cristian, por favor escriba la opci�n del monto a retirar|");
		System.out.println("===========================================================");
		x = saldo.nextInt();
		System.out.println("===========================================================");

		 int billetes_de_100=0;
	        int billetes_de_1000=0;
		int billetes_de_300=0;
	        int billetes_de_200=0;
	        int billetes_de_50=0;
	        int billetes_de_500=0;
	        int cantidad_de_dinero=0;
	        System.out.print("Ingrese el valor de cantidad de dinero: ");
	        cantidad_de_dinero = saldo.nextInt();
	        int cant=0;
	        cant=cantidad_de_dinero;
		        if(cantidad_de_dinero<=5000 &&cantidad_de_dinero>0){
			        	if(cantidad_de_dinero/1000>2){
			        		billetes_de_1000=2;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*2;
			        	}else{
			                billetes_de_1000=cantidad_de_dinero/1000;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*billetes_de_1000;
			        	}
			        	if(cantidad_de_dinero/500>4){
			        		billetes_de_500=4;
			        		cantidad_de_dinero=cantidad_de_dinero-500*4;
			        	}else{
			                billetes_de_500=cantidad_de_dinero/500;
			            	cantidad_de_dinero=cantidad_de_dinero-500*billetes_de_500;
			        	}

				if(cantidad_de_dinero/300>10){
			        		billetes_de_300=10;
			        		cantidad_de_dinero=cantidad_de_dinero-300*10;
			        	}else{
			                billetes_de_300=cantidad_de_dinero/300;
			            	cantidad_de_dinero=cantidad_de_dinero-300*billetes_de_300;
			        	}
			        	if(cantidad_de_dinero/200>5){
			        		billetes_de_200=5;
			        		cantidad_de_dinero=cantidad_de_dinero-200*5;
			        	}else{
			                billetes_de_200=cantidad_de_dinero/200;
			            	cantidad_de_dinero=cantidad_de_dinero-200*billetes_de_200;
			        	}
 
		            	if(cantidad_de_dinero/100>10){
			        		billetes_de_100=10;
			        		cantidad_de_dinero=cantidad_de_dinero-100*10;
			        	}else{
			                billetes_de_100=cantidad_de_dinero/100;
			            	cantidad_de_dinero=cantidad_de_dinero-100*billetes_de_100;
			        	}
 
		            	if(cantidad_de_dinero/50>10){
			        		billetes_de_50=10;
			        		cantidad_de_dinero=cantidad_de_dinero-50*10;
			        	}else{
			                billetes_de_50=cantidad_de_dinero/50;
			            	cantidad_de_dinero=cantidad_de_dinero-50*billetes_de_50;
			        	}
		        }
			System.out.println("Valor de billetes de 1000: " + billetes_de_1000);
		        System.out.println("Valor de billetes de 500: " + billetes_de_500);
			System.out.println("Valor de billetes de 300: " + billetes_de_300);
		        System.out.println("Valor de billetes de 200: " + billetes_de_200);
		        System.out.println("Valor de billetes de 100: " + billetes_de_100);
		        System.out.println("Valor de billetes de 50: " + billetes_de_50);

		if (x == 1){
			saldo1 = saldo1 - a;
			max = max + a;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q50|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 2){
			saldo1 = saldo1 - s;
			max = max + s;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q100|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 3){
			saldo1 = saldo1 - d;
			max = max + d;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q200|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 4){
			saldo1 = saldo1 - f;
			max = max + f;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q300|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 5){
			saldo1 = saldo1 - g;
			max = max + g;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q500|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 6){
			saldo1 = saldo1 - h;
			max = max + h;
			System.out.println("=================================================");
			System.out.println("|Cristian usted hizo un retiro equivalente a Q1000|");
			System.out.println("=======================================================");
			System.out.println("|Cristian por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Cristian, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Cristian su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}
		break;

		case 3:
		System.out.println("====================================");
		System.out.println("|Ingrese el monto que desea retirar|");
		System.out.println("====================================");
		int mvariable2;
		mvariable = saldo.nextInt();
		System.out.println("==========================================");
		mvariable1 = mvariable / 50;
		mvariable2 = mvariable % 50;	
			
			if(mvariable > 2000){
			System.out.println("\n~~~~~ No puede retirar mas de 2000 quetzales ~~~~~");
			}else if (mvariable == saldo1){
			System.out.println("$$$$$ ESTIMADO CRISTIAN USTED NO PUEDE RETIRAR TODO SU DINERO $$$$$");
			}else if(mvariable1 >= 1 && mvariable2 == 0){
			saldo1 = saldo1 - mvariable;
			System.out.println("Cristian usted retiro la cantidad de : " + mvariable);
			System.out.println("=====================================================================");
			System.out.println("Transaccion finalizada, su numero de transaccion es: " + numTrans);
			System.out.println("=====================================================================");
			System.out.println("Cristian tu saldo es :" + saldo1);
			System.out.println("==================================");
			}else if (mvariable1 < 1 || mvariable2 != 0 ){
			System.out.println("Estimado Cristian solo puede hacer retiros derivados de multiplos de 50");
			System.out.println("======================================================================");
			}
				
		
		break;
	
		default:
		System.out.println("Ingrese una opcion valida");
				}
					System.out.println("\n �Desea salir?");
					System.out.println("1. No");
					System.out.println("2. Si");
					sal = saldo.nextInt();	}

		//*************************************** SEGUNDO USUARIO *********************************	
		
		}else if (usuario.equals("Kevin") && contrasenia.equals("2101")){
			System.out.println("|Bienvenido a tu cuenta bancaria|");
		//***** Menu de opciones *****
	int sal = 0;
	while(sal <= 1){
	System.out.println("==============================");
	System.out.println("|***** Menu de opciones *****|");
	System.out.println("==============================");
	System.out.println("1.Consultar saldo");
	int saldo1 = 5000;
	System.out.println("2.Realizar debito");
	System.out.println("3.Realizar debito variable");
	System.out.println("==============================");
	System.out.println("+++++ Escoja una opcion +++++");
	System.out.println("==============================");
	int op;
	op = saldo.nextInt();
	System.out.println("==============================");
	int a,s,d,f,g,h,x, mvariable1, mvaraible2;
	int mvariable;
	int max = 0;
	a = 50;
	s = 100;
	d = 200;
	f = 300;
	g = 500;
	h = 1000;
	
	switch(op){
		
		case 1:
		System.out.println("|Su saldo actual es: " + saldo1 + "|");
		System.out.println("==============================");
		break;
		
		
		case 2:
		System.out.println("+++++ Escoja una opcion +++++");
		x = 0;
		System.out.println("1. 50");
		System.out.println("2. 100");
		System.out.println("3. 200");
		System.out.println("4. 300");
		System.out.println("5. 500");
		System.out.println("6. 1000");
		System.out.println("===========================================================");
		System.out.println("|Kevin, por favor escriba la opci�n del monto a retirar|");
		System.out.println("===========================================================");
		x = saldo.nextInt();
		System.out.println("===========================================================");

		 int billetes_de_100=0;
	        int billetes_de_1000=0;
		int billetes_de_300=0;
	        int billetes_de_200=0;
	        int billetes_de_50=0;
	        int billetes_de_500=0;
	        int cantidad_de_dinero=0;
	        System.out.print("Ingrese el valor de cantidad de dinero: ");
	        cantidad_de_dinero = saldo.nextInt();
	        int cant=0;
	        cant=cantidad_de_dinero;
		        if(cantidad_de_dinero<=5000 &&cantidad_de_dinero>0){
			        	if(cantidad_de_dinero/1000>2){
			        		billetes_de_1000=2;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*2;
			        	}else{
			                billetes_de_1000=cantidad_de_dinero/1000;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*billetes_de_1000;
			        	}
			        	if(cantidad_de_dinero/500>4){
			        		billetes_de_500=4;
			        		cantidad_de_dinero=cantidad_de_dinero-500*4;
			        	}else{
			                billetes_de_500=cantidad_de_dinero/500;
			            	cantidad_de_dinero=cantidad_de_dinero-500*billetes_de_500;
			        	}

				if(cantidad_de_dinero/300>10){
			        		billetes_de_300=10;
			        		cantidad_de_dinero=cantidad_de_dinero-300*10;
			        	}else{
			                billetes_de_300=cantidad_de_dinero/300;
			            	cantidad_de_dinero=cantidad_de_dinero-300*billetes_de_300;
			        	}
			        	if(cantidad_de_dinero/200>5){
			        		billetes_de_200=5;
			        		cantidad_de_dinero=cantidad_de_dinero-200*5;
			        	}else{
			                billetes_de_200=cantidad_de_dinero/200;
			            	cantidad_de_dinero=cantidad_de_dinero-200*billetes_de_200;
			        	}
 
		            	if(cantidad_de_dinero/100>10){
			        		billetes_de_100=10;
			        		cantidad_de_dinero=cantidad_de_dinero-100*10;
			        	}else{
			                billetes_de_100=cantidad_de_dinero/100;
			            	cantidad_de_dinero=cantidad_de_dinero-100*billetes_de_100;
			        	}
 
		            	if(cantidad_de_dinero/50>10){
			        		billetes_de_50=10;
			        		cantidad_de_dinero=cantidad_de_dinero-50*10;
			        	}else{
			                billetes_de_50=cantidad_de_dinero/50;
			            	cantidad_de_dinero=cantidad_de_dinero-50*billetes_de_50;
			        	}
		        }
			System.out.println("Valor de billetes de 1000: " + billetes_de_1000);
		        System.out.println("Valor de billetes de 500: " + billetes_de_500);
			System.out.println("Valor de billetes de 300: " + billetes_de_300);
		        System.out.println("Valor de billetes de 200: " + billetes_de_200);
		        System.out.println("Valor de billetes de 100: " + billetes_de_100);
		        System.out.println("Valor de billetes de 50: " + billetes_de_50);

		if (x == 1){
			saldo1 = saldo1 - a;
			max = max + a;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q50|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 2){
			saldo1 = saldo1 - s;
			max = max + s;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q100|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 3){
			saldo1 = saldo1 - d;
			max = max + d;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q200|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 4){
			saldo1 = saldo1 - f;
			max = max + f;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q300|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 5){
			saldo1 = saldo1 - g;
			max = max + g;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q500|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 6){
			saldo1 = saldo1 - h;
			max = max + h;
			System.out.println("=================================================");
			System.out.println("|Kevin usted hizo un retiro equivalente a Q1000|");
			System.out.println("=======================================================");
			System.out.println("|Kevin por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Kevin, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Kevin su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}
		break;

		case 3:
		System.out.println("====================================");
		System.out.println("|Ingrese el monto que desea retirar|");
		System.out.println("====================================");
		int mvariable2;
		mvariable = saldo.nextInt();
		System.out.println("==========================================");
		mvariable1 = mvariable / 50;
		mvariable2 = mvariable % 50;	
			
			if(mvariable > 2000){
			System.out.println("\n~~~~~ No puede retirar mas de 2000 quetzales ~~~~~");
			}else if (mvariable == saldo1){
			System.out.println("$$$$$ ESTIMADO KEVIN NO PUEDE RETIRAR TODO SU DINERO $$$$$");
			}else if(mvariable1 >= 1 && mvariable2 == 0){
			saldo1 = saldo1 - mvariable;
			System.out.println("Kevin usted retiro la cantidad de : " + mvariable);
			System.out.println("=====================================================================");
			System.out.println("Transaccion finalizada, su numero de transaccion es: " + numTrans);
			System.out.println("=====================================================================");
			System.out.println("Kevin tu nuevo saldo es :" + saldo1);
			System.out.println("==================================");
			}else if (mvariable1 < 1 || mvariable2 != 0 ){
			System.out.println("Estimado Kevin solo puede hacer retiros derivados de multiplos de 50");
			System.out.println("======================================================================");
			}
				
		
		break;
	
		default:
		System.out.println("Ingrese una opcion valida");
				}
					System.out.println("\n �Desea salir?");
					System.out.println("1. No");
					System.out.println("2. Si");
					sal = saldo.nextInt();	}

	//______________________ TERCER USUARIO____________________________
		
		}else if (usuario.equals("Ana") && contrasenia.equals("2018")){
			System.out.println("|Bienvenido a tu cuenta bancaria|");
		//***** Menu de opciones *****
	int sal = 0;
	while(sal <= 1){
	System.out.println("==============================");
	System.out.println("|***** Menu de opciones *****|");
	System.out.println("==============================");
	System.out.println("1.Consultar saldo");
	int saldo1 = 15000;
	System.out.println("2.Realizar debito");
	System.out.println("3.Realizar debito variable");
	System.out.println("==============================");
	System.out.println("+++++ Escoja una opcion +++++");
	System.out.println("==============================");
	int op;
	op = saldo.nextInt();
	System.out.println("==============================");
	int a,s,d,f,g,h,x, mvariable1, mvaraible2;
	int mvariable;
	int max = 0;
	a = 50;
	s = 100;
	d = 200;
	f = 300;
	g = 500;
	h = 1000;
	
	switch(op){
		
		case 1:
		System.out.println("|Su saldo actual es: " + saldo1 + "|");
		System.out.println("==============================");
		break;
		
		
		case 2:
		System.out.println("+++++ Escoja una opcion +++++");
		x = 0;
		System.out.println("1. 50");
		System.out.println("2. 100");
		System.out.println("3. 200");
		System.out.println("4. 300");
		System.out.println("5. 500");
		System.out.println("6. 1000");
		System.out.println("===========================================================");
		System.out.println("|Ana, por favor escriba la opci�n del monto a retirar|");
		System.out.println("===========================================================");
		x = saldo.nextInt();
		System.out.println("===========================================================");

		 int billetes_de_100=0;
	        int billetes_de_1000=0;
		int billetes_de_300=0;
	        int billetes_de_200=0;
	        int billetes_de_50=0;
	        int billetes_de_500=0;
	        int cantidad_de_dinero=0;
	        System.out.print("Ingrese el valor de cantidad de dinero: ");
	        cantidad_de_dinero = saldo.nextInt();
	        int cant=0;
	        cant=cantidad_de_dinero;
		        if(cantidad_de_dinero<=5000 &&cantidad_de_dinero>0){
			        	if(cantidad_de_dinero/1000>2){
			        		billetes_de_1000=2;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*2;
			        	}else{
			                billetes_de_1000=cantidad_de_dinero/1000;
			        		cantidad_de_dinero=cantidad_de_dinero-1000*billetes_de_1000;
			        	}
			        	if(cantidad_de_dinero/500>4){
			        		billetes_de_500=4;
			        		cantidad_de_dinero=cantidad_de_dinero-500*4;
			        	}else{
			                billetes_de_500=cantidad_de_dinero/500;
			            	cantidad_de_dinero=cantidad_de_dinero-500*billetes_de_500;
			        	}

				if(cantidad_de_dinero/300>10){
			        		billetes_de_300=10;
			        		cantidad_de_dinero=cantidad_de_dinero-300*10;
			        	}else{
			                billetes_de_300=cantidad_de_dinero/300;
			            	cantidad_de_dinero=cantidad_de_dinero-300*billetes_de_300;
			        	}
			        	if(cantidad_de_dinero/200>5){
			        		billetes_de_200=5;
			        		cantidad_de_dinero=cantidad_de_dinero-200*5;
			        	}else{
			                billetes_de_200=cantidad_de_dinero/200;
			            	cantidad_de_dinero=cantidad_de_dinero-200*billetes_de_200;
			        	}
 
		            	if(cantidad_de_dinero/100>10){
			        		billetes_de_100=10;
			        		cantidad_de_dinero=cantidad_de_dinero-100*10;
			        	}else{
			                billetes_de_100=cantidad_de_dinero/100;
			            	cantidad_de_dinero=cantidad_de_dinero-100*billetes_de_100;
			        	}
 
		            	if(cantidad_de_dinero/50>10){
			        		billetes_de_50=10;
			        		cantidad_de_dinero=cantidad_de_dinero-50*10;
			        	}else{
			                billetes_de_50=cantidad_de_dinero/50;
			            	cantidad_de_dinero=cantidad_de_dinero-50*billetes_de_50;
			        	}
		        }
			System.out.println("Valor de billetes de 1000: " + billetes_de_1000);
		        System.out.println("Valor de billetes de 500: " + billetes_de_500);
			System.out.println("Valor de billetes de 300: " + billetes_de_300);
		        System.out.println("Valor de billetes de 200: " + billetes_de_200);
		        System.out.println("Valor de billetes de 100: " + billetes_de_100);
		        System.out.println("Valor de billetes de 50: " + billetes_de_50);

		if (x == 1){
			saldo1 = saldo1 - a;
			max = max + a;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q50|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 2){
			saldo1 = saldo1 - s;
			max = max + s;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q100|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 3){
			saldo1 = saldo1 - d;
			max = max + d;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q200|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 4){
			saldo1 = saldo1 - f;
			max = max + f;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q300|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 5){
			saldo1 = saldo1 - g;
			max = max + g;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q500|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}else if (x == 6){
			saldo1 = saldo1 - h;
			max = max + h;
			System.out.println("=================================================");
			System.out.println("|Ana usted hizo un retiro equivalente a Q1000|");
			System.out.println("=======================================================");
			System.out.println("|Ana por favor espere, transacci�n en proceso....|");
			System.out.println("====================================================================");
			System.out.println("\nFelicidades Ana, su n�mero de transaccion es: " + numTrans);
			System.out.println("====================================================================");
			System.out.println("Ana su saldo actual es: " + saldo1);
			System.out.println("==================================");
			}
		break;

		case 3:
		System.out.println("====================================");
		System.out.println("|Ingrese el monto que desea retirar|");
		System.out.println("====================================");
		int mvariable2;
		mvariable = saldo.nextInt();
		

		System.out.println("==========================================");
		mvariable1 = mvariable / 50;
		mvariable2 = mvariable % 50;	
			
			if(mvariable > 2000){
			System.out.println("\n~~~~~ No puede retirar mas de 2000 quetzales ~~~~~");
			}else if (mvariable == saldo1){
			System.out.println("$$$$$ ESTIMADA ANA NO PUEDE RETIRAR TODO SU DINERO $$$$$");
			}else if(mvariable1 >= 1 && mvariable2 == 0){
			saldo1 = saldo1 - mvariable;
			System.out.println("Ana usted retiro la cantidad de : " + mvariable);
			System.out.println("=====================================================================");
			System.out.println("Transaccion finalizada, su numero de transaccion es: " + numTrans);
			System.out.println("=====================================================================");
			System.out.println("Ana tu nuevo saldo es :" + saldo1);
			System.out.println("==================================");
			}else if (mvariable1 < 1 || mvariable2 != 0 ){
			System.out.println("Estimado Ana solo puede hacer retiros derivados de multiplos de 50");
			System.out.println("======================================================================");
			}
				
		
		break;
	
		default:
		System.out.println("Ingrese una opcion valida");
				}
					System.out.println("\n �Desea salir?");
					System.out.println("1. No");
					System.out.println("2. Si");
					sal = saldo.nextInt();	}
	

		}else{ 
		System.out.println("Ususario o contrase�a incorrecta");
			
		}
	}	
}